def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

print("GCD(48, 18):", gcd(48, 18)) 
print("GCD(101, 10):", gcd(101, 10))  
print("GCD(56, 98):", gcd(56, 98)) 

def extended_gcd(a, b):
    if b == 0:
        return (a, 1, 0)
    else:
        gcd_val, x1, y1 = extended_gcd(b, a % b)
        x = y1
        y = x1 - (a // b) * y1
        return (gcd_val, x, y)

def modular_inverse(a, n):
    gcd_val, x, _ = extended_gcd(a, n)
    if gcd_val != 1:
        return None 
    else:
        return x % n  

print("Extended GCD(30, 20):", extended_gcd(30, 20))  
print("Modular inverse of 3 mod 11:", modular_inverse(3, 11)) 
print("Modular inverse of 10 mod 17:", modular_inverse(10, 17))
print("Modular inverse of 6 mod 9:", modular_inverse(6, 9))  
