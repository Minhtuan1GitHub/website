def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

print("GCD of 48 and 18:", gcd(48, 18))

def extended_gcd(a, b):
    if b == 0:
        return a, 1, 0
    gcd, x1, y1 = extended_gcd(b, a % b)
    x = y1
    y = x1 - (a // b) * y1
    return gcd, x, y

print("Extended GCD of 30 and 20:", extended_gcd(30, 20))

def mod_inverse(a, n):
    gcd, x, _ = extended_gcd(a, n)
    if gcd != 1:
        return None 
    return x % n

print("Modular inverse of 3 mod 26:", mod_inverse(3, 26))

def find_mod_inverses(numbers, n):
    inverses = {}
    for num in numbers:
        inverses[num] = mod_inverse(num, n)
    return inverses

numbers = [3, 4, 5, 6]
print("Modular inverses in Z26:", find_mod_inverses(numbers, 26))

def coprimes_and_inverses(n):
    coprimes = []
    inverses = {}
    for a in range(1, n):
        if gcd(a, n) == 1:
            coprimes.append(a)
            inverses[a] = mod_inverse(a, n)
    return coprimes, inverses

print("Coprimes and inverses of 26:", coprimes_and_inverses(26))

def multiplicative_cipher_brute_force(ciphertext, n):
    plaintexts = []
    for a in range(1, n):
        if gcd(a, n) == 1:
            a_inverse = mod_inverse(a, n)
            plaintext = ''.join(chr((a_inverse * (ord(c) - ord('A'))) % n + ord('A')) if c.isalpha() else c for c in ciphertext)
            plaintexts.append((a, plaintext))
    return plaintexts

ciphertext = "ZEBRAS"
print("Brute-force attack results:", multiplicative_cipher_brute_force(ciphertext, 26))

def affine_decryption_key(a, b, n):
    a_inverse = mod_inverse(a, n)
    if a_inverse is None:
        raise ValueError("a has no modular inverse in Z{}".format(n))
    return a_inverse, (-b * a_inverse) % n

print("Affine decryption key of (5, 8, 26):", affine_decryption_key(5, 8, 26))

def affine_encrypt(text, a, b, n):
    if mod_inverse(a, n) is None:
        raise ValueError("a has no modular inverse in Z{}".format(n))
    return ''.join(chr(((a * (ord(c) - ord('A')) + b) % n) + ord('A')) if c.isalpha() else c for c in text)

def affine_decrypt(cipher_text, a, b, n):
    a_inverse, b_inverse = affine_decryption_key(a, b, n)
    return ''.join(chr((a_inverse * (ord(c) - ord('A') - b) % n) + ord('A')) if c.isalpha() else c for c in cipher_text)

plain_text = "HELLO"
a, b, n = 5, 8, 26
encrypted = affine_encrypt(plain_text, a, b, n)
decrypted = affine_decrypt(encrypted, a, b, n)
print("Affine cipher encryption:", encrypted)
print("Affine cipher decryption:", decrypted)

def rsa_private_exponent(p, q, b):
    phi_n = (p - 1) * (q - 1)
    return mod_inverse(b, phi_n)

print("RSA private key exponent:", rsa_private_exponent(61, 53, 17))

def generate_rsa_keys(p, q, e):
    n = p * q
    phi_n = (p - 1) * (q - 1)
    d = mod_inverse(e, phi_n)
    return (n, e, d)

def rsa_encrypt(m, e, n):
    return pow(m, e, n)

def rsa_decrypt(c, d, n):
    return pow(c, d, n)

p, q, e = 61, 53, 17
n, e, d = generate_rsa_keys(p, q, e)
message = 65
encrypted_message = rsa_encrypt(message, e, n)
decrypted_message = rsa_decrypt(encrypted_message, d, n)
print("RSA keys:", (n, e, d))
print("RSA encryption:", encrypted_message)
print("RSA decryption:", decrypted_message)